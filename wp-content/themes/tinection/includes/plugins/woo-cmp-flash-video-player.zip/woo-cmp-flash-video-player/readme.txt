=== Woo CMP Flash Video Player ===
Contributors: softrial
Donate link: http://www.softrial.info/woocmp
Tags: player, flash player, simple, video, audio, skins, mp3, woocmp
Requires at least: 3.0
Tested up to: 3.5.0
Stable tag: 1.0
License: GPLv2

Create player with multiple skins via shortcode succinctly!

== Description ==

This plugin provide a shortcode to create player. You can change skins through shortcode and players with different appearance can be created anywhere of your site.

== Installation ==

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in your posts/pages

* Base structure of shortcode (these parameters must be set with value):
`[woocmp preview="" video="" duration=""]`

* Full option shortcode:
`[woocmp preview="" video="" duration="" width="" height="" skin="" fullscreen="" autostart=""]`

Example:
`[woocmp preview="http://www.softrial.info/attachments/cover.jpg" video="http://www.softrial.info/attachments/video.mp4" duration="30" width="600" height="400" fullscreen="true" autostart="false" skin="10"]`


== Frequently Asked Questions ==
= What's this player? =

this plugin helps you create player via shortcode and the player is developed from CMP which is an open flash player.

= What's the skin? =
the skins offer different apperance of players for viewers,the value of skin parameter is from 1-20, and 1-13 are video player skins while 14-20 are audio player skins.


== Screenshots ==

1. Player in action

== Changelog ==
= 1.0 =
* Start the work...